#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <map>

using namespace std;

int n, a[100001];
map<int, int> c;
const int P = 1000000007;

int main() {
	freopen("square.in", "r", stdin);
	freopen("square.out", "w", stdout);
	c.clear();
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		int x;
		scanf("%d", &x);
		for (int j = 2; j * j <= x; j++)
			if (!(x % j)) {
				int cnt = 0;
				for (; !(x % j); x /= j, ++cnt);
				if (cnt % 2)
				    ++c[j];
			}
		if (x != 1)
			++c[x];
	}
	long long ans = 1;
	for (auto itr : c) {
		int res = min(itr.second, n - itr.second);
		for (int i = 1; i <= res; i++)
			ans *= itr.first, ans %= P;
	}
	printf("%lld\n", ans);
}

