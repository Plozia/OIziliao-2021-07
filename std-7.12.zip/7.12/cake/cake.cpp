#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <set>

using namespace std;

struct node {
    int v, p1, p2;
    bool operator < (const node &A) const {
        return v < A.v;
    }
} c[200001];
struct node1 {
    int y, z, v, p;
    bool operator < (const node1 &A) const {
        if (y != A.y)
            return y < A.y;
        return z < A.z;
    }
} g[200001];
struct node2 {
    int t, u, y, z;
    bool operator < (const node2 &A) const {
        if (t != A.t)
            return t < A.t;
        return u < A.u;
    }
} e[4][400001];
struct tree {
    int k, v, p;
} q[4][1000001];
int n, a[100001][6], v[200001][3], U[3], f[1000001], p[200001][2], len[4], V[4];
set< pair<int, int> > s[4];

inline void insert(int k, int Left, int Right, int x, int y) {
    f[k] = max(f[k], y);
    if (Left == Right)
        return;
    int i = (Left + Right) >> 1;
    if (x <= i)
        insert(k + k, Left, i, x, y);
    else
        insert(k + k + 1, i + 1, Right, x, y);
}

int calc(int k, int Left, int Right, int s, int t) {
    if (Left == s && Right == t)
        return f[k];
    int i = (Left + Right) >> 1;
    if (t <= i)
        return calc(k + k, Left, i, s, t);
    else
        if (s > i)
            return calc(k + k + 1, i + 1, Right, s, t);
        else
            return max(calc(k + k, Left, i, s, i), calc(k + k + 1, i + 1, Right, i + 1, t));
}

inline void work(int idx, int x, int y) {
    for (int i = 1; i <= 4 * U[2]; i++)
        f[i] = -1e9;
    for (int i = 1; i <= n; i++) {
        g[i].y = a[i][x]; 
        g[i].z = a[i][y]; 
        g[i].v = a[i][0];
        g[i].p = i;
    }
    sort(g + 1, g + n + 1);
    for (int i = n; i; --i) {
        int x = g[i].z;
        if (x < 0)
            x = U[2] + x + 1;
        p[g[i].p][0] = calc(1, 1, U[2], x, U[2]);
        //printf("i %d %d %d %d\n", g[i].p, x, g[i].v, p[g[i].p][0]);
        insert(1, 1, U[2], x, g[i].v - 1);
    }
    
    for (int i = 1; i <= 4 * U[2]; i++)
        f[i] = -1e9;
    for (int i = 1; i <= n; i++) {
        g[i].y = a[i][x]; 
        g[i].z = a[i][y]; 
        g[i].v = -a[i][3];
        g[i].p = i;
    }
    sort(g + 1, g + n + 1);
    for (int i = n; i; --i) {
        int x = g[i].z;
        if (x < 0)
            x = U[2] + x + 1;
        p[g[i].p][1] = -calc(1, 1, U[2], x, U[2]);
        insert(1, 1, U[2], x, g[i].v - 1);
    }
    
    for (int i = 1; i <= n; i++) {
        int L = p[i][0] + 1, R = p[i][1] - 1;
        //printf("try %d %d %d\n", i, L, R);
        if (L > R)
            continue;
        //printf("xxx %d %d\n", a[i][0], a[i][3]);
        int M = min(a[i][0] - 1, R);
        if (L <= M && M)
            e[idx][++len[idx]].y = a[i][x] - 1,
            e[idx][len[idx]].z = a[i][y] - 1,
            e[idx][len[idx]].t = L,
            e[idx][len[idx]].u = 0,
            e[idx][++len[idx]].y = a[i][x] - 1,
            e[idx][len[idx]].z = a[i][y] - 1,
            e[idx][len[idx]].t = M,
            e[idx][len[idx]].u = 1;
        M = max(a[i][3] + 1, L);
        if (M <= R)
            e[idx][++len[idx]].y = a[i][x] - 1,
            e[idx][len[idx]].z = a[i][y] - 1,
            e[idx][len[idx]].t = M,
            e[idx][len[idx]].u = 0,
            e[idx][++len[idx]].y = a[i][x] - 1,
            e[idx][len[idx]].z = a[i][y] - 1,
            e[idx][len[idx]].t = R,
            e[idx][len[idx]].u = 1;
    }
    
    for (int i = 1; i <= len[idx]; i++)
        e[idx][i].y = abs(e[idx][i].y),
        e[idx][i].z = abs(e[idx][i].z);
    
    sort(e[idx] + 1, e[idx] + len[idx] + 1);
    
    /*if (idx == 2) {
        printf("%d\n", idx);
        for (int i = 1; i <= len[idx]; i++)
            printf("%d %d %d %d\n", e[idx][i].y, e[idx][i].z, e[idx][i].t, e[idx][i].u);
    }*/
}

inline void down(int idx, int k) {
    if (q[idx][k].k) {
        q[idx][k + k].k += q[idx][k].k;
        q[idx][k + k + 1].k += q[idx][k].k;
        q[idx][k].k = 0;
    }
}

inline void up(int idx, int k) {
    q[idx][k].v = q[idx][k + k].v + q[idx][k + k].k;
    q[idx][k].p = q[idx][k + k].p;
    int x = q[idx][k + k + 1].v + q[idx][k + k + 1].k;
    if (x < q[idx][k].v) {
        q[idx][k].v = x;
        q[idx][k].p = q[idx][k + k + 1].p;
    }
}

inline void buildtree(int idx, int k, int Left, int Right) {
    q[idx][k].v = q[idx][k].k = 0;
    q[idx][k].p = Left;
    if (Left == Right) {
        if (Left == 0 || Left == U[1] + 1)
            q[idx][k].v = 1e9;
        return;
    }
    int i = (Left + Right) >> 1;
    buildtree(idx, k + k, Left, i);
    buildtree(idx, k + k + 1, i + 1, Right);
    up(idx, k);
}

inline void add(int idx, int k, int Left, int Right, int s, int t, int y) {
    //if (k == 1 && idx == 3)
    //    printf("adding %d %d %d %d\n", idx, s, t, y);
    if (Left == s && Right == t) {
        q[idx][k].k += y;
        return;
    }
    down(idx, k);
    int i = (Left + Right) >> 1;
    if (t <= i)
        add(idx, k + k, Left, i, s, t, y);
    else
        if (s > i)
            add(idx, k + k + 1, i + 1, Right, s, t, y);
        else
            add(idx, k + k, Left, i, s, i, y), add(idx, k + k + 1, i + 1, Right, i + 1, t, y);
    up(idx, k);
}

pair<int, int> calc1(int idx, int k, int Left, int Right, int s, int t) {
    if (Left == s && Right == t)
        return make_pair(q[idx][k].k + q[idx][k].v, q[idx][k].p);
    down(idx, k);
    pair<int, int> res;
    int i = (Left + Right) >> 1;
    if (t <= i)
        res = calc1(idx, k + k, Left, i, s, t);
    else
        if (s > i)
            res = calc1(idx, k + k + 1, i + 1, Right, s, t);
        else
            res = min(calc1(idx, k + k, Left, i, s, i), calc1(idx, k + k + 1, i + 1, Right, i + 1, t));
    up(idx, k);
    return res;
}

inline void output(int i, int j) {
    auto itr1 = lower_bound(s[0].begin(), s[0].end(), make_pair(j, 0));
    auto itr2 = lower_bound(s[3].begin(), s[3].end(), make_pair(j, int(1e9)));
    --itr2;
    int k = max(itr1->second, itr2->second) + 1;
    //printf("win %d %d %d\n", i, j, k);
    printf("YES\n");
    //printf("%d %d %d\n", i, j, k);
    printf("%d %d %d\n", v[i][0], v[j][1], v[k][2]);
}

int main() {
	freopen("cake.in", "r", stdin);
	freopen("cake.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) 
        scanf("%d%d%d%d%d%d", &a[i][0], &a[i][3], &a[i][1], &a[i][4], &a[i][2], &a[i][5]);
    for (int i = 0; i < 3; i++) {
        int cnt = 0;
        for (int j = 1; j <= n; j++)
            c[++cnt].v = a[j][i], c[cnt].p1 = j, c[cnt].p2 = i,
            c[++cnt].v = a[j][i + 3], c[cnt].p1 = j, c[cnt].p2 = i + 3;
        sort(c + 1, c + cnt + 1);
        for (int j = 1; j <= cnt; j++) {
            if (j == 1 || c[j].v != c[j - 1].v)
                ++U[i], v[U[i]][i] = c[j].v;
            a[c[j].p1][c[j].p2] = U[i];
        }
    }
    /*for (int i = 0; i < 3; i++) {
        for (int j = 1; j <= U[i]; j++)
            printf("%d ", v[j][i]);
        printf("\n");
    }*/
    /*for (int i = 1; i <= n; i++) {
        for (int j = 0; j < 6; j++)
            printf("%d ", a[i][j]);
        printf("\n");
    }*/
    work(0, 1, 2);
    
    for (int i = 1; i <= n; i++)
        a[i][5] = -a[i][5];
    work(1, 1, 5);
    for (int i = 1; i <= n; i++)
        a[i][4] = -a[i][4];
    work(2, 4, 5);
    for (int i = 1; i <= n; i++)
        a[i][5] = -a[i][5];
    work(3, 4, 2);
    for (int i = 1; i <= n; i++)
        a[i][4] = -a[i][4];
    
    for (int i = 0; i < 4; i++) {
        s[i].clear();
        V[i] = 1;
        buildtree(i, 1, 0, U[1] + 1);
    }
    
    //printf("U %d %d %d\n", U[0], U[1], U[2]);
    
    s[0].insert(make_pair(0, U[2] + 1));
    s[0].insert(make_pair(U[1] + 1, 0));
    
    s[1].insert(make_pair(0, 0));
    s[1].insert(make_pair(U[1] + 1, U[2] + 1));
    
    s[2].insert(make_pair(0, U[2] + 1));
    s[2].insert(make_pair(U[1] + 1, 0));
    
    s[3].insert(make_pair(0, 0));
    s[3].insert(make_pair(U[1] + 1, U[2] + 1));
    
    //for (int i = 0; i < 4; i++) 
    //    for (; V[i] <= len[i] && e[i][V[i]].t < 1; ++V[i]);
    
    for (int i = 1; i <= U[0]; i++) {
        //printf("wowo %d %d\n", i, U[0]);
        for (; V[0] <= len[0] && e[0][V[0]].t <= i && !e[0][V[0]].u; ++V[0]) {
            int y = e[0][V[0]].y, z = e[0][V[0]].z;
            if (y == U[1] + 1 || y == 0)
                continue;
            //printf("i %d %d\n", y, z);
            auto itr2 = lower_bound(s[0].begin(), s[0].end(), make_pair(y, z));
            auto itr1 = itr2; --itr1;
            //printf("add %d %d\n", itr1->first, y);
            add(0, 1, 0, U[1] + 1, itr1->first + 1, y, z - itr2->second);
            add(1, 1, 0, U[1] + 1, itr1->first + 1, y, z - itr2->second);
            s[0].insert(make_pair(y, z));
        }
        //printf("huo\n");
        for (; V[1] <= len[1] && e[1][V[1]].t <= i && !e[1][V[1]].u; ++V[1]) {
            int y = e[1][V[1]].y, z = e[1][V[1]].z;
            if (y == U[1] + 1 || y == 0)
                continue;
            auto itr2 = lower_bound(s[1].begin(), s[1].end(), make_pair(y, z));
            auto itr1 = itr2; --itr1;
            add(0, 1, 0, U[1] + 1, itr1->first + 1, y, itr2->second - z);
            add(2, 1, 0, U[1] + 1, itr1->first + 1, y, itr2->second - z);
            s[1].insert(make_pair(y, z));
        }
        //printf("!\n");
        for (; V[2] <= len[2] && e[2][V[2]].t <= i && !e[2][V[2]].u; ++V[2]) {
            int y = e[2][V[2]].y, z = e[2][V[2]].z;
            //printf("insert %d %d\n", y, z);
            if (y == U[1] + 1 || y == 0)
                continue;
            auto itr2 = lower_bound(s[2].begin(), s[2].end(), make_pair(y, z));
            auto itr1 = itr2; --itr1;
            add(1, 1, 0, U[1] + 1, y, itr2->first - 1, itr1->second - z);
            add(3, 1, 0, U[1] + 1, y, itr2->first - 1, itr1->second - z);
            s[2].insert(make_pair(y, z));
        }
        //printf("!\n");
        for (; V[3] <= len[3] && e[3][V[3]].t <= i && !e[3][V[3]].u; ++V[3]) {
            int y = e[3][V[3]].y, z = e[3][V[3]].z;
            if (y == U[1] + 1 || y == 0)
                continue;
            //printf("insert? %d %d\n", y, z);
            auto itr2 = lower_bound(s[3].begin(), s[3].end(), make_pair(y, z));
            auto itr1 = itr2; --itr1;
            add(2, 1, 0, U[1] + 1, y, itr2->first - 1, z - itr1->second);
            add(3, 1, 0, U[1] + 1, y, itr2->first - 1, z - itr1->second);
            s[3].insert(make_pair(y, z));
        }
        
        /*if (i == 5) {
        
        printf("s[0]\n");
        for (auto itr : s[0])
            printf("%d %d\n", itr.first, itr.second);
        
        printf("s[1]\n");
        for (auto itr : s[1])
            printf("%d %d\n", itr.first, itr.second);
        
        printf("s[2]\n");
        for (auto itr : s[2])
            printf("%d %d\n", itr.first, itr.second);
        
        printf("s[3]\n");
        for (auto itr : s[3])
            printf("%d %d\n", itr.first, itr.second);
        
        }*/
        
        int Left = 0, Right = U[1] + 1, Mid = (Left + Right) >> 1;
        for (; Left + 1 < Right; Mid = (Left + Right) >> 1) {
            auto itr1 = lower_bound(s[0].begin(), s[0].end(), make_pair(Mid, 0));
            auto itr2 = lower_bound(s[3].begin(), s[3].end(), make_pair(Mid, int(1e9)));
            --itr2;
            //if (i == 2) 
            //    printf("%d %d %d %d %d\n", Mid, itr1->first, itr1->second, itr2->first, itr2->second);
            if (itr1->second >= itr2->second)
                Left = Mid;
            else
                Right = Mid;
        }
        
        /*if (i == 12) {
        printf("wjh %d %d\n", Left, Right);
        }*/
        int L = 0, R = U[1] + 1, M = (L + R) >> 1;
        for (; L + 1 < R; M = (L + R) >> 1) {
            auto itr1 = lower_bound(s[1].begin(), s[1].end(), make_pair(M, 0));
            auto itr2 = lower_bound(s[2].begin(), s[2].end(), make_pair(M, int(1e9)));
            --itr2;
            if (itr1->second <= itr2->second)
                L = M;
            else
                R = M;
        }
        
        //if (i == 5) {
        //printf("wjh %d %d %d %d\n", Left, Right, L, R);
        //}
        //printf("%d %d %d %d\n", Left, Right, L, R);
        
        auto res = calc1(0, 1, 0, U[1] + 1, 0, min(Left, L));
        //if (i == 5) printf("res %d %d\n", res.first, res.second);
        if (res.first < U[2]) {
            output(i, res.second);
            return 0;
        }
        
        res = calc1(3, 1, 0, U[1] + 1, max(Right, R), U[1] + 1);
        //if (i == 5) 
        //    printf("res %d %d\n", res.first, res.second);
        if (res.first < U[2]) {
            output(i, res.second);
            return 0;
        }
        
        if (R <= Left) {        
            res = calc1(1, 1, 0, U[1] + 1, R, Left);
        //if (i == 5) 
        //    printf("res1 %d %d\n", res.first, res.second);
            if (res.first < U[2]) {
                output(i, res.second);
                return 0;
            }
        }

        if (Right <= L) {        
            res = calc1(2, 1, 0, U[1] + 1, Right, L);
        //if (i == 2) 
        //    printf("res2 %d %d\n", res.first, res.second);
            if (res.first < U[2]) {
                output(i, res.second);
                return 0;
            }
        }
        
        for (; V[0] <= len[0] && e[0][V[0]].t <= i && e[0][V[0]].u; ++V[0]) {
            int y = e[0][V[0]].y, z = e[0][V[0]].z;
            if (y == U[1] + 1 || y == 0)
                continue;
            s[0].erase(make_pair(y, z));
            auto itr2 = lower_bound(s[0].begin(), s[0].end(), make_pair(y, z));
            auto itr1 = itr2; --itr1;
            add(0, 1, 0, U[1] + 1, itr1->first + 1, y, itr2->second - z);
            add(1, 1, 0, U[1] + 1, itr1->first + 1, y, itr2->second - z);
        }
        for (; V[1] <= len[1] && e[1][V[1]].t <= i && e[1][V[1]].u; ++V[1]) {
            int y = e[1][V[1]].y, z = e[1][V[1]].z;
            if (y == U[1] + 1 || y == 0)
                continue;
            s[1].erase(make_pair(y, z));
            auto itr2 = lower_bound(s[1].begin(), s[1].end(), make_pair(y, z));
            auto itr1 = itr2; --itr1;
            add(0, 1, 0, U[1] + 1, itr1->first + 1, y, z - itr2->second);
            add(2, 1, 0, U[1] + 1, itr1->first + 1, y, z - itr2->second);
        }
        for (; V[2] <= len[2] && e[2][V[2]].t <= i && e[2][V[2]].u; ++V[2]) {
            int y = e[2][V[2]].y, z = e[2][V[2]].z;
            if (y == U[1] + 1 || y == 0)
                continue;
            //printf("delete %d %d\n", y, z);
            s[2].erase(make_pair(y, z));
            auto itr2 = lower_bound(s[2].begin(), s[2].end(), make_pair(y, z));
            auto itr1 = itr2; --itr1;
            add(1, 1, 0, U[1] + 1, y, itr2->first - 1, z - itr1->second);
            add(3, 1, 0, U[1] + 1, y, itr2->first - 1, z - itr1->second);
        }
        for (; V[3] <= len[3] && e[3][V[3]].t <= i && e[3][V[3]].u; ++V[3]) {
            int y = e[3][V[3]].y, z = e[3][V[3]].z;
            if (y == U[1] + 1 || y == 0)
                continue;
            //printf("delete? %d %d\n", y, z);
            s[3].erase(make_pair(y, z));
            auto itr2 = lower_bound(s[3].begin(), s[3].end(), make_pair(y, z));
            auto itr1 = itr2; --itr1;
            add(2, 1, 0, U[1] + 1, y, itr2->first - 1, itr1->second - z);
            add(3, 1, 0, U[1] + 1, y, itr2->first - 1, itr1->second - z);
        }
    }
    
    printf("NO\n");
}
