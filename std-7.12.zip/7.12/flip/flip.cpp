#include <bits/stdc++.h>
using namespace std;
#define rep(i,a,n) for (int i=a;i<n;i++)
#define per(i,a,n) for (int i=n-1;i>=a;i--)
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second
#define SZ(x) ((int)(x).size())
typedef vector<int> VI;
typedef long long ll;
typedef pair<int,int> PII;
typedef double db;
const ll mod=1000000007;
ll powmod(ll a,ll b) {ll res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
ll gcd(ll a,ll b) { return b?gcd(b,a%b):a;}
// head

const int N=510;
int stk[N],top,L[N],R[N],n,m,id[N][N];
ll ans[N*N];
PII a[N];

void build(int n) {
	int top=0;
	a[0]=mp(-1,-1);
	stk[top++]=0;
	rep(i,1,n+1) {
		while (top>0&&a[stk[top-1]]>a[i]) --top;
		L[i]=stk[top-1];
		stk[top++]=i;
	}
	a[n+1]=mp(-1,-1);
	top=0;
	stk[top++]=n+1;
	per(i,1,n+1) {
		while (top>0&&a[stk[top-1]]>a[i]) --top;
		R[i]=stk[top-1];
		stk[top++]=i;
	}
	rep(i,1,n+1) {
		//printf("%d %d %d %d\n",a[i].fi,i,L[i],R[i]);
		ans[a[i].fi]+=(i-L[i])*(R[i]-i);
	}
}

int main() {
	freopen("flip.in", "r", stdin);
	freopen("flip.out", "w", stdout); 
	scanf("%d%d",&n,&m);
	rep(i,0,n*m) {
		int x,y;
		scanf("%d%d",&x,&y);
		--x; --y;
		id[x][y]=i;
	}
	rep(L,0,n) {
		rep(j,1,m+1) a[j]=mp(n*m+1,-1);
		rep(R,L,n) {
			rep(j,1,m+1) a[j]=min(a[j],mp(id[R][j-1],j));
			build(m);
		}
	}
	per(i,0,n*m) ans[i]+=ans[i+1];
	rep(i,1,n*m+1) printf("%lld\n",ans[i]);
}
