#include<bits/stdc++.h>
 
#define y1 dmytxdy
#define pb push_back
#define fi first
#define se second
#define mp make_pair
 
using namespace std;
 
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef long double ld;
 
template <typename T> bool chkmin(T &x,T y){return x>y?x=y,1:0;}
template <typename T> bool chkmax(T &x,T y){return x<y?x=y,1:0;}
 
int readint(){
	int x=0,f=1; char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
 
const int cys=998244353;
 
ll f2(ll x){return x*(x+1)%cys*(x+x+1)%cys*((cys+1)/6)%cys;}
 
ll getans(int x1,int y1,int x2,int y2){
	if(x1==x2){
		if(y1<y2) return (f2(y2)-f2(y1)+1ll*y1*y1-1ll*y2*y2+1ll*(y2-y1)*x1%cys*x1)%cys;
		else return (f2(y1)-f2(y2)+1ll*(y1-y2)*x1%cys*x1)%cys;
	}
	if(y1==y2){
		if(x1<x2) return (f2(x2)-f2(x1)+1ll*x1*x1-1ll*x2*x2+1ll*(x2-x1)*y1%cys*y1)%cys;
		else return (f2(x1)-f2(x2)+1ll*(x1-x2)*y1%cys*y1)%cys;
	}
	if(x1==y1&&x2==y2){
		if(x1<x2) return ((2*(f2(x2)-f2(x1))-1ll*x2*x2+1ll*x1*x1)%cys+(f2(x2)-f2(x1)-1ll*x2*x2+1ll*x1*x1)*2%cys)%cys;
		else return (2*(f2(x1)-f2(x2))%cys+(2*(f2(x1)-f2(x2))-1ll*x1*x1+1ll*x2*x2)%cys)%cys;
	}
	if(x1<x2){
		if(y1>=y2) return (getans(x1,y1,x1,y2)+getans(x1,y2,x2,y2))%cys;
		if(x1>=y1&&x2>=y2){
			if(x1<=y2) return (getans(x1,y1,x1,x1)+getans(x1,x1,y2,y2)+getans(y2,y2,x2,y2))%cys;
			else return (getans(x1,y1,x1,y2)+getans(x1,y2,x2,y2))%cys;
		}
		if(x1<y1&&x2<y2){
			if(y1<=x2) return (getans(x1,y1,y1,y1)+getans(y1,y1,x2,x2)+getans(x2,x2,x2,y2))%cys;
			else return (getans(x1,y1,x2,y1)+getans(x2,y1,x2,y2))%cys;
		}
		if(x1>=y1&&x2<y2) return (getans(x1,y1,x1,x1)+getans(x1,x1,x2,x2)+getans(x2,x2,x2,y2))%cys;
		return (getans(x1,y1,y1,y1)+getans(y1,y1,y2,y2)+getans(y2,y2,x2,y2))%cys;
	}
	else{
		if(y1<=y2) return (getans(x1,y1,x2,y1)+getans(x2,y1,x2,y2))%cys;
		if(x1>=y1&&x2>=y2){
			if(y1<=x2) return (getans(x1,y1,x2,y1)+getans(x2,y1,x2,y2))%cys;
			else return (getans(x1,y1,y1,y1)+getans(y1,y1,x2,x2)+getans(x2,x2,x2,y2))%cys;
		}
		if(x1<y1&&x2<y2){
			if(x1<=y2) return (getans(x1,y1,x1,y2)+getans(x1,y2,x2,y2))%cys;
			else return (getans(x1,y1,x1,x1)+getans(x1,x1,y2,y2)+getans(y2,y2,x2,y2))%cys;
		}
		if(x1>=y1&&x2<y2) return (getans(x1,y1,y1,y1)+getans(y1,y1,y2,y2)+getans(y2,y2,x2,y2))%cys;
		return (getans(x1,y1,x1,x1)+getans(x1,x1,x2,x2)+getans(x2,x2,x2,y2))%cys;
	}
}
 
int main(){
	freopen("go.in", "r", stdin);
	freopen("go.out", "w", stdout);
	int n=readint(),x1,y1,x2,y2;
	for(int i=1;i<=n;i++){
		x1=readint(); y1=readint(); x2=readint(); y2=readint();
		if(x1<0) x1=-x1,x2=-x2;
		if(y1<0) y1=-y1,y2=-y2;
		ll ans=1ll*x2*x2%cys*y2%cys*y2-1ll*x1*x1%cys*y1%cys*y1;
		ans%=cys;
		if(x2>=0&&y2>=0) ans=(ans+getans(x1,y1,x2,y2))%cys;
		else if(x2>=0&&y2<0) ans=(ans+getans(x1,y1,min(x1,x2),0)+getans(min(x1,x2),0,x2,-y2))%cys;
		else if(x2<0&&y2>=0) ans=(ans+getans(x1,y1,0,min(y1,y2))+getans(0,min(y1,y2),-x2,y2))%cys;
		else ans=(ans+getans(x1,y1,0,0)+getans(0,0,-x2,y2))%cys;
		printf("%lld\n",(ans+cys)%cys);
	}
	return 0;
}
