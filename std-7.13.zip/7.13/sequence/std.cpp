#include <bits\stdc++.h>
#include <vector>

using namespace std;

struct node {
    int key, sum0, sum1, t0, t1;
    long long tot0, tot1;
} f[5000001];
int n, m, a[510001], pre[510001], r[510001];
long long ans[510001], res;
vector<pair<int, int> > c[510001];

inline void down(int k) {
    if (!f[k + k].key)
        f[k + k].t1 += f[k].t1, f[k + k].t0 += f[k].t0;
    else
        f[k + k].t1 += f[k].t0, f[k + k].t0 += f[k].t1;
    if (!f[k + k + 1].key)
        f[k + k + 1].t1 += f[k].t1, f[k + k + 1].t0 += f[k].t0;
    else
        f[k + k + 1].t1 += f[k].t0, f[k + k + 1].t0 += f[k].t1;
    f[k].t1 = 0;
    f[k].t0 = 0;
    f[k + k].key ^= f[k].key;
    f[k + k + 1].key ^= f[k].key;
    f[k].key = 0;
}

inline void up(int k) {
    f[k].sum0 = f[k + k].sum0;
    f[k].sum1 = f[k + k].sum1;
    if (f[k + k].key)
        swap(f[k].sum0, f[k].sum1);
    int x = f[k + k + 1].sum0, y = f[k + k + 1].sum1;
    if (f[k + k + 1].key)
        swap(x, y);
    f[k].sum0 += x; 
    f[k].sum1 += y;
    
    f[k].tot0 = f[k + k].tot0 + 1LL * f[k + k].sum0 * f[k + k].t0;
    f[k].tot1 = f[k + k].tot1 + 1LL * f[k + k].sum1 * f[k + k].t1; 
    if (f[k + k].key)
        swap(f[k].tot0, f[k].tot1);
    long long xx = f[k + k + 1].tot0 + 1LL * f[k + k + 1].sum0 * f[k + k + 1].t0,
              yy = f[k + k + 1].tot1 + 1LL * f[k + k + 1].sum1 * f[k + k + 1].t1;
    if (f[k + k + 1].key)
        swap(xx, yy);
    f[k].tot0 += xx;
    f[k].tot1 += yy;
}

inline void inc(int k, int Left, int Right, int x, int y) {
    if (Left == Right) {
        if (f[k].key)
            f[k].sum0 += y,
            f[k].tot0 -= y * f[k].t0;
        else
            f[k].sum1 += y,
            f[k].tot1 -= y * f[k].t1;
        return;
    }
    down(k);
    int i = (Left + Right) >> 1;
    if (x <= i)
        inc(k + k, Left, i, x, y);
    else
        inc(k + k + 1, i + 1, Right, x, y);
    up(k);
    //printf("%d %d %d %d %d %lld %lld\n", k, Left, Right, f[k].sum0, f[k].sum1, f[k].tot0, f[k].tot1);
}

inline void reverse(int k, int Left, int Right, int s, int t) {
    if (Left == s && Right == t) {
        f[k].key ^= 1;
        return;
    }
    down(k);
    int i = (Left + Right) >> 1;
    if (t <= i)
        reverse(k + k, Left, i, s, t);
    else
        if (s > i)
            reverse(k + k + 1, i + 1, Right, s, t);
        else
            reverse(k + k, Left, i, s, i), reverse(k + k + 1, i + 1, Right, i + 1, t);
    up(k);
}       

long long calc(int k, int Left, int Right, int s, int t) {
    if (Left == s && Right == t) {
        return f[k].tot0 + 1LL * f[k].sum0 * f[k].t0 + f[k].tot1 + 1LL * f[k].sum1 * f[k].t1;
    }
    down(k);
    int i = (Left + Right) >> 1;
    long long res = 0;
    if (t <= i)
        res = calc(k + k, Left, i, s, t);
    else
        if (s > i)
            res = calc(k + k + 1, i + 1, Right, s, t);
        else
            res = calc(k + k, Left, i, s, i) + calc(k + k + 1, i + 1, Right, i + 1, t);
    up(k);
    return res;
}

int main() {
    scanf("%d", &n);
    memset(c, 0, sizeof(c));
    for (int i = 1; i <= n; i++)
        scanf("%d", &a[i]);
    for (int i = 1; i <= n; i++) {
        pre[i] = r[a[i]];
        r[a[i]] = i;
    }
    scanf("%d", &m);
    for (int i = 1; i <= m; i++) {
        int l, r;
        scanf("%d%d", &l, &r);
        c[r].push_back(make_pair(l - 1, i));
    }
    for (int i = 1; i <= n; i++) {
        inc(1, 1, n, i, 1);
        reverse(1, 1, n, pre[i] + 1, i);
        if (!f[1].key)
            f[1].t0++;
        else
            f[1].t1++;
        res = calc(1, 1, n, 1, n);
        for (auto j : c[i]) {
            ans[j.second] += res;
            if (j.first)
                ans[j.second] -= calc(1, 1, n, 1, j.first);
        }
    }
    for (int i = 1; i <= m; i++)
        printf("%lld\n", ans[i]);
}
    
