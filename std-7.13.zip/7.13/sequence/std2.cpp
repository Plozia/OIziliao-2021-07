#include<bits/stdc++.h>
#define F(i,l,r) for(int i=l;i<r;++i)
#define pr(...) //fprintf(stderr,__VA_ARGS__)
const int N=1e6+8,R=N*50;
struct io
{
	char ibuf[1 << 25] , * s , obuf[1 << 25] , * t;
	int a[24];
	io() : t( obuf )
	{
		fread( s = ibuf , 1 , 1 << 25 , stdin );
	}
	~io()
	{
		fwrite( obuf , 1 , t - obuf , stdout );
	}
	inline int read()
	{
		register int u = 0;
		while( * s < 48 )
			s++;
		while( * s > 32 )
			u = u * 10 + * s++ - 48;
		return u;
	}
	template < class T >
	inline void print( T u , int v )
	{
		print( u );
		* t++ = v;
	}
	template < class T >
	inline void print( register T u )
	{
		static int * q = a;
		if( !u ) * t++ = 48;
		else
		{
			if( u < 0 )
				* t++ = 45 , u *= -1;
			while( u ) * q++ = u % 10 + 48 , u /= 10;
			while( q != a )
				* t++ = * --q;
		}
	}
} ip;

#define read ip.read
#define print ip.print

typedef long long i64;
i64 ans[N];
int n,m,pv[N],a[N];

struct node{
	node *lc,*rc;
	int L,R,M,sz;
	i64 sum=0;
	int t1=0,t0=0;
	int c1=0;
	bool rev=0;
	node(){}
	node(node *lc,node *rc,int L,int R,int M,int sz) : lc( lc ) , rc( rc ) , L( L ) , R( R ) , M( M ) , sz( sz ) {}
	void app(int _t1,int _t0,int _rev){
		sum+=i64(_t1)*c1+i64(_t0)*(sz-c1);
		if(!rev)t1+=_t1,t0+=_t0;
		else t1+=_t0,t0+=_t1;
		if(_rev)rev=!rev,c1=sz-c1;
	}
	void dn(){
		if(!(t1|t0|rev))return;
		lc->app(t1,t0,rev);
		rc->app(t1,t0,rev);
		t1=t0=0;
		rev=0;
	}
	void up(){
		sum=lc->sum+rc->sum;
		c1=lc->c1+rc->c1;
	}
	void modify(int l,int r){
		if(l<=L&&R<=r)return app(0,0,1);
		dn();
		if(l<=M)lc->modify(l,r);
		if(r>M)rc->modify(l,r);
		up();
	}
	i64 query(int l,int r){
		if(l<=L&&R<=r)return sum;
		dn();
		i64 s=0;
		if(l<=M)s+=lc->query(l,r);
		if(r>M)s+=rc->query(l,r);
		return s;
	}
}ns[N*2],*np=ns,*rt;

node *build(int l,int r){
	if(l==r){
		*np=node(0,0,l,r,0,1);
		return np++;
	}
	int m=(l+r)/2;
	node*lc=build(l,m);
	node*rc=build(m+1,r);
	*np=node(lc,rc,l,r,m,r-l+1);
	return np++;
}

struct Q{
	int l,r,id;
	void init(int i){
		l=read();
		r=read();
		id=i;
	}
	bool operator<(const Q&w)const{return r<w.r;}
	void cal(){
		ans[id]=rt->query(l,r);
	}
}qs[N];

int main(){
	n=read();
	F(i,1,n+1)a[i]=read();
	rt=build(1,n);
	m=read();
	F(i,0,m)qs[i].init(i);
	std::sort(qs,qs+m);
	int p=0;
	F(i,1,n+1){
		int l=pv[a[i]]+1;
		pv[a[i]]=i;
		rt->modify(l,i);
		rt->app(1,0,0);
		for(;p<m&&qs[p].r==i;++p)qs[p].cal();
	}
	F(i,0,m)print(ans[i] , 10);
	return 0;
}
