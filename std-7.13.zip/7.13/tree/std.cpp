#include <cmath>
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;
typedef long long LL;
#define N 100000 + 5

#define EASY_MODE

int n, A[N];
vector<int> Vec[N];
LL W[N], Dp[N][2];

struct Frac
{
	LL fz;
	int fm;
	Frac() {}
	Frac(LL fz, int fm) : fz(fz), fm(fm) {}
	void out() const
	{
#ifdef EASY_MODE
		printf("%.9f\n", (double)(fz) / fm);
#else
		LL d = __gcd(fz, LL(fm));
		printf("%lld/%d\n", fz / d, fm / d);
#endif
	}
}F[N];

bool operator < (const Frac &lhs, const Frac &rhs)
{
	return lhs.fz * rhs.fm < rhs.fz * lhs.fm;
}

void dfs(int z)
{
	Dp[z][0] = W[z];
	for (int d : Vec[z])
	{
		dfs(d);
		Dp[z][0] += max(Dp[d][0], 0LL);
	}
}

void DFS(int z)
{
	for (int d : Vec[z])
	{
		Dp[d][1] = max(Dp[z][1] + Dp[z][0] - max(Dp[d][0], 0LL), 0LL);
		DFS(d);
	}
}

bool Check(const Frac &k)
{
	for (int i = 1; i <= n; i ++)
		W[i] = 1LL * A[i] * k.fm - k.fz;
	dfs(1);
	DFS(1);
	for (int i = 1; i <= n; i ++)
		if (Dp[i][0] + Dp[i][1] < 0)
			return false;
	return true;
}

void BinarySearch(LL &l, LL &r, int op)
{
	while (l < r)
	{
		LL mid = l + r + 1 >> 1;
		if (Check(op == 0 ? Frac(mid, n) : F[mid]))
			l = mid;
		else r = mid - 1;
	}
}

int main()
{
	scanf("%d", &n);
	for (int i = 1; i <= n; i ++)
		scanf("%d", A + i);
	for (int i = 2, p; i <= n; i ++)
	{
		scanf("%d", &p);
		Vec[p].push_back(i);
	}
	LL l = 1LL * (*min_element(A + 1, A + n + 1)) * n;
	LL r = 1LL * (*max_element(A + 1, A + n + 1)) * n;
	BinarySearch(l, r, 0);
	for (int i = 1; i <= n; i ++)
		F[i] = Frac((l * i + n - 1) / n, i);
	sort(F + 1, F + n + 1);
	l = 1, r = n;
	BinarySearch(l, r, 1);
	F[l].out();
	return 0;
}
