#include <bits/stdc++.h>

using namespace std;

const string YES = "YES";
const string NO = "NO";
const int L = 1e9;

FILE* fout, *fans, *flog;
string In, Out, Ans, Log;

int n, a[100001][6];

void End(const string& info, double x, int state = 0){
    fprintf(flog, "%.3lf\n%s\n", x, info.c_str());
    exit(state);
}

void Open(){
    if (Log.size()) flog = fopen(Log.c_str(), "w"); else flog = stdout;
    if (flog == NULL) exit(1);
    if ((fans = fopen(Ans.c_str(), "r")) == NULL) exit(1);
    if ((fout = fopen(Out.c_str(), "r")) == NULL) exit(1);
}

int main(int argc, char * argv[])
{
	In = argc < 2 ? "" : argv[1];
    Ans = argc < 3 ? "" : argv[2];
    Out = argc < 4 ? "" : argv[3];
    Log = argc < 5 ? "" : argv[4];
    Open();
			 
    double stdans, outans;
	freopen(Ans.c_str(),"r",stdin);//�ض��򵽱�׼���
	cin>>stdans;
	
	fclose(stdin);cin.clear(); 
    freopen(Out.c_str(),"r",stdin);//�ض���ѡ�����
    cin>>outans;
    
    double eps = 1e-6;
    
	if (fabs(stdans-outans)<=eps||fabs(stdans-outans)/stdans<=eps)
		End( "Correct!" , 1 );
	else 
    	End( "Wrong Answer" , 0 );
}
