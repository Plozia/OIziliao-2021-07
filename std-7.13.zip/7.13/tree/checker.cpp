#include "testlib.h"
double myabs(double x){return x>(-1e-15)?x:-x;}
int main(int argc, char* argv[])
{
	registerTestlibCmd(argc, argv);
	double pans=ouf.readDouble();
	double jans=ans.readDouble();
	double eps=1e-6;
	if (myabs(pans-jans)<eps||myabs(pans-jans)/jans<eps)quitf(_ok,"ykuouzfAKIOI");
	else quitf(_wa,"GG expected = %f,found = %f",jans,pans);
}