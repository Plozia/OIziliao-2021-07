#include<bits/stdc++.h>
using namespace std;

const int P = 998244353; int dp[5][62][62] , N; string s;
void inc(int &a , int b){a = (a + b) % P;}

int cnt[62] , sum , sumdlt;
int binom2(int x){return x * (x - 1ll) / 2 % P;}
void add(int x){++sum; inc(sumdlt , cnt[x]++);}
void del(int x){--sum; inc(sumdlt , P - (--cnt[x]));}
int qry(int x , int y){
	return (0ll + binom2(sum - cnt[x] - cnt[y]) - sumdlt + P + binom2(cnt[x]) + binom2(cnt[y])) % P;
}

int convert(char c) {
    if('a' <= c && c <= 'z') return c - 'a';
    else if('A' <= c && c <= 'Z') return 26 + c - 'A';
    else return 52 + c - '0';
}
int main(){
	cin >> s; N = s.size(); int ans = 0; for(auto t : s) add(convert(t));
	for(int i = 0 ; i < 62 ; ++i) for(int j = 0 ; j < 62 ; ++j) if(i != j) dp[0][i][j] = 1;
	for(int i = s.size() - 1 ; ~i ; --i){
		int t = convert(s[i]); del(t);
		for(int k = 0 ; k < 62 ; ++k)
			if(k != t){
				inc(dp[1][k][t] , dp[0][k][t]);
				inc(dp[3][k][t] , dp[2][k][t]);
				inc(dp[2][t][k] , dp[1][t][k]);
				ans = (ans + 1ll * dp[3][t][k] * qry(t , k)) % P;
			}
	}
	cout << ans; return 0;
}

