#include<bits/stdc++.h>
using namespace std;
typedef long long i64;
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	int T;
	for(scanf("%d",&T);T;--T){
		i64 n,m,a,b;
		scanf("%lld%lld%lld%lld",&n,&m,&a,&b);
		assert(0<=n&&n<=1000000000000000000LL);
		if(m>1000000000000000000LL)cerr<<m<<endl; 
		assert(0<=m&&m<=1000000000000000000LL);
		assert(1<=b&&b<=1000000000000000000LL);
		assert(1<=a&&a<b);
		i64 x=m/b,y=m%b,c=b-a;
		puts((n==0?m==0:(x<n-1||x==n-1&&(y<=b/2||(b-y)%c==0&&(b-y)/c<=n)||x==n&&y==0))?"Yes":"No");
	}
	return 0;
}
