#include <iostream>
#include <stdio.h>
#include <math.h>

using namespace std;

unsigned int n , t;
long long ans;

inline unsigned int read()
{
	register unsigned int x = 0 , ch = getchar();
	while( !isdigit( ch ) ) ch = getchar();
	while( isdigit( ch ) ) x = x * 10 + ch - '0' , ch = getchar();
	return x;
}

inline long long cal( long long x , long long y , long long z , long long k )
{
	return k * 1ll * ( x + y ) + k * 1ll * ( k + 1 ) / 2 * z;
}

inline long long cal()
{
	long long x = read() , y = read() , z = read() , l = 1 , r = t , ans = 0 , mid;
	if( z ) r = sqrt( 2 * t / z ) + 233333;
	y -= z;
	while( l <= r )
	{
		mid = l + r >> 1;
		if( cal( x , y , z , mid ) <= t ) l = mid + 1 , ans = mid;
		else r = mid - 1;
	}
	return ans * 1ll * x + min( t - cal( x , y , z , ans ) , 1ll * x );
}

int main()
{
	freopen( "a.in" , "r" , stdin );
	freopen( "a.out" , "w" , stdout ); 
	n = read() , t = read();
	while( n-- ) ans += t - cal();
	cout << ans << endl;
	return 0;
}
