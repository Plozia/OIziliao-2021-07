#include <iostream>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <time.h>
#define MAXN 2000010
#define mod 19260817

using namespace std;

int n , m , x[ MAXN ] , y[ MAXN ] , fa[ MAXN ] , vis[ MAXN ] , belong[ MAXN ] , f[ MAXN ] , spe[ MAXN ] , cir , ans;
vector < int > linker[ MAXN ];

inline void update( int & x , int y )
{
	x += y;
	if( x >= mod ) x -= mod;
}

inline void addedge( int x , int y )
{
	linker[x].push_back( y ) , linker[y].push_back( x );
}

struct io
{
	char op[1 << 25] , * s;
	io()
	{
		freopen("c.in","r",stdin);
		freopen("c.out","w",stdout); 
		s[ fread( s = op , 1 , 1 << 25 , stdin ) ] = 0;
	}
	inline int read()
	{
		register int u = 0;
		while( * s < 48 ) s++;
		while( * s > 32 )
			u = u * 10 + * s++ - 48;
		return u;
	}
} ip;

#define read ip.read

#define cur linker[x][i]

void dfs( int x )
{
	vis[x] = 1;
	for( int i = 0 ; i < linker[x].size() ; i++ )
		if( cur != fa[x] )
			if( !vis[ cur ] ) fa[ cur ] = x , dfs( cur );
			else if( !belong[ cur ] )
			{
				int v = x;
				spe[ ++cir ] = 1;
				while( 1 )
				{
					belong[v] = cir;
					if( v == cur ) break;
					v = fa[v];
				}
			}
}

void dp( int x )
{
	for( int i = 0 ; i < linker[x].size() ; i++ )
		if( cur != fa[x] )
			fa[ cur ] = x , dp( cur ) , update( ans , f[x] * ( spe[x] ? 2ll : 1ll ) * f[ cur ] % mod ) , update( f[x] , f[ cur ] );
	if( spe[x] ) update( ans , f[x] ) , update( f[x] , f[x] + 1 );
}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	n = read() , m = read();
	for( register int i = 1 ; i <= m ; i++ ) addedge( x[i] = read() , y[i] = read() );
	dfs( 1 );
	for( register int i = 1 ; i <= n ; i++ )
	{
		linker[i].clear();
		if( !belong[i] )
			belong[i] = ++cir;
	}
	for( register int i = 1 ; i <= m ; i++ )
		if( belong[ x[i] ] != belong[ y[i] ] )
			addedge( belong[ x[i] ] , belong[ y[i] ] );
	memset( fa , 0 , sizeof( fa ) );
	dp( 1 );
	cout << ans << endl;
	return 0;
}
