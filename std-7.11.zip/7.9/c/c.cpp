#include <iostream>
#include <stdio.h>
#include <string.h>
#define MAXN 500010

using namespace std;

int n , m , k;
short f[ MAXN ][ 210 ];
char a[ MAXN ] , b[ MAXN ];

inline void update( short & a , short b )
{
	if( a > b ) a = b;
}

int main()
{
	freopen( "c.in" , "r" , stdin );
	freopen( "c.out" , "w" , stdout );
	cin >> n >> m >> k >> a + 1 >> b + 1;
	memset( f , 127 , sizeof( f ) );
	if( a[n + 1] || b[m + 1] ) while( 1 );
	k++;
	f[0][k] = 0;
	for( int i = 0 ; i <= n ; i++ )
		for( int j = i - k ; j <= i + k ; j++ )
		{
			if( i >= 1 ) 
				update( f[i][j - i + k] , f[i - 1][j - ( i - 1 ) + k] + 1 );
			if( j >= 1 )
				update( f[i][j - i + k] , f[i][j - 1 - i + k] + 1 );
			if( i >= 1 && j >= 1 )
				update( f[i][j - i + k] , f[i - 1][j - 1 - ( i - 1 ) + k] + ( a[i] == b[j] ? 0 : 2 ) );
		}
	int v = f[n][m - n + k];
	k--;
	if( v > k ) cout << -1 << endl;
	else cout << v << endl;
	return 0;
}
