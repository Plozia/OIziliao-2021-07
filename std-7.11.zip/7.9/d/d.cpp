#include<bits/stdc++.h>
const int Mxn=300005;
using namespace std;
int n,m,fa[Mxn],l[Mxn],r[Mxn],lv[Mxn],add[Mxn],sub[Mxn];
int ans[Mxn],jmp[Mxn],cth[Mxn*2],ctc[Mxn*3],aa[Mxn],as[Mxn];
vector<int> son[Mxn],qlca[Mxn],qadd[Mxn],qsub[Mxn];
int fft(int rt)
{
	if(jmp[rt]!=rt)
		jmp[rt]=fft(jmp[rt]);
	return jmp[rt];
}
void dfs1(int rt,int lev)
{
	lv[rt]=lev;
	for(int i=0;i<son[rt].size();i++)
		if(lv[son[rt][i]])
			fa[rt]=son[rt][i];
		else
			dfs1(son[rt][i],lev+1);
	for(int i=0;i<qlca[rt].size();i++)
		if(!ans[qlca[rt][i]])
			if(l[qlca[rt][i]]==rt)
				if(jmp[r[qlca[rt][i]]]!=r[qlca[rt][i]])
					ans[qlca[rt][i]]=fft(r[qlca[rt][i]]);
				else;
			else
				if(jmp[l[qlca[rt][i]]]!=l[qlca[rt][i]])
					ans[qlca[rt][i]]=fft(l[qlca[rt][i]]);
				else;
	jmp[rt]=fa[rt];
}
void dfs2(int rt)
{
	cth[rt+lv[rt]]++;
	ctc[lv[rt]-rt+n]++;
	for(int i=0;i<qadd[rt].size();i++)
		aa[qadd[rt][i]]=abs(aa[qadd[rt][i]]-cth[add[qadd[rt][i]]]);
	for(int i=0;i<qsub[rt].size();i++)
		as[qsub[rt][i]]=abs(as[qsub[rt][i]]-ctc[sub[qsub[rt][i]]]);
	for(int i=0;i<son[rt].size();i++)
		if(son[rt][i]!=fa[rt])
			dfs2(son[rt][i]);
	cth[rt+lv[rt]]--;
	ctc[lv[rt]-rt+n]--;
}
int main()
{
	freopen("d.in", "r", stdin);
	freopen("d.out", "w", stdout);
	int u,v;
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&u,&v);
		son[u].push_back(v);
		son[v].push_back(u);
		jmp[i]=i;
	}
	jmp[n]=n;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&l[i],&r[i]);
		qlca[l[i]].push_back(i);
		qlca[r[i]].push_back(i);
	}
	dfs1(1,1);
	for(int i=1;i<=m;i++)
	{
		add[i]=lv[l[i]];
		sub[i]=lv[ans[i]]*2-lv[l[i]]+n;
		qadd[ans[i]].push_back(i);
		qadd[l[i]].push_back(i);
		qsub[fa[ans[i]]].push_back(i);
		qsub[r[i]].push_back(i);
	}
	dfs2(1);
	for(int i=1;i<=m;i++)
		printf("%d\n",aa[i]+as[i]);
    return 0;
}
