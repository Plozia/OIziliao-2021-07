#include <bits/stdc++.h>
using namespace std;

int n, ans = 0x3f3f3f3f, now, col[10], ans_col[10];
int main()
{
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);
	scanf("%d", &n);
	if (n <= 6)
	{
		printf("%d\n", (n + 1) / 2);
		for (int i = 1; i <= n; i++)
			printf("%d ", (i + 1) / 2);
	}
	else
	{
		puts("4");
		for (int i = 1; i <= n; i++)
			printf("%d ", 1 + (i & 3));
		return 0;
	}
	return 0;
}
