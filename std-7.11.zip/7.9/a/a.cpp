#include<cstdio>
using namespace std;
long long n,m,ans;
int main(){
	freopen( "a.in" , "r" , stdin );
	freopen( "a.out" , "w" , stdout );
	scanf("%lld%lld",&n,&m);
    if(m>100000){
		printf("1");
		return 0;
	}
	for(int i=1;;i++){
		long long sum=1;
		for(int j=1;j<=m;j++) sum*=i;
		if(sum<=n) ans++;
		else break;
	}
	printf("%lld",ans);
	return 0;
}
