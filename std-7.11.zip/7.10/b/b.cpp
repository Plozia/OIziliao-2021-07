#include <iostream>
#include <stdio.h>
#define MAXN 1000010
#define mod 19260817

using namespace std;

int a[16] = { 47 , 43 , 41 , 37 , 31 , 29 , 23 , 19 , 17 , 13 , 11 , 7 , 5 , 3 , 2 } , ans , t;
long long n;

void dfs( int x , long long now , int v , int l )
{
	if( x == 15 )
		ans = max( ans , v );
	else
	{
		long long t = 1;
		for( register int i = 1 ; i <= l ; i++ )
		{
			t *= a[x];
			if( t > n / now ) return;
		}
		for( int i = l ; t <= n / now ; i++ , t *= a[x] )
			dfs( x + 1 , now * t , v * ( i + 1 ) , i );
	}
}

int main()
{
		freopen( "b.in" , "r" , stdin );
	freopen( "b.out" , "w" , stdout );
	cin >> t;
	while( t-- )
	{
		ans = 0;
		cin >> n;
		dfs( 0 , 1 , 1 , 0 );
		cout << ans << endl;
	}
	return 0;
}
