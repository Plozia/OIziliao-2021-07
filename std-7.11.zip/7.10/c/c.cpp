#include <iostream>
#include <stdio.h>
#define MAXN 1000010

using namespace std;

int n , m , x , a[ MAXN ] , f[21][ MAXN ] , pre[ MAXN ];

struct io
{
	char ibuf[1 << 25] , * s , obuf[1 << 24] , * t;
	int a[24];
	io() : t( obuf )
	{
		freopen( "c.in" , "rb" , stdin );
		freopen( "c.out" , "w" , stdout );
		fread( s = ibuf , 1 , 1 << 25 , stdin );
	}
	~io()
	{
		fwrite( obuf , 1 , t - obuf , stdout );
	}
	inline int read()
	{
		register int u = 0;
		while( * s < 48 ) s++;
		while( * s > 32 )
			u = u * 10 + * s++ - 48;
		return u;
	}
	inline void pt( int u )
	{
		static int * q = a;
		if( !u ) * t++ = 48;
		else
		{
			while( u ) * q++ = u % 10 + 48 , u /= 10;
			while( q != a )
				* t++ = * --q;
		}
	}
	inline void print( int a )
	{
		if( a >= 0 )
			pt( a );
		else
			* t++ = 'C' , * t++ = 'h' , * t++ = 't' , * t++ = 'h' , * t++ = 'o' , * t++ = 'l' , * t++ = 'l' , * t++ = 'y';
		* t++ = '\n';
	}
} ip;

#define read ip.read
#define print ip.print

int main()
{
	n = read() , m = read() , x = read();
	for( register int i = 1 ; i <= n ; i++ )
		a[i] = read() , pre[i] = pre[i - 1] + ( a[i] > x );
	for( register int i = n , r = n , now = 0 ; i ; i-- )
	{
		now += a[i];
		while( now > x ) now -= a[ r-- ];
		f[0][i] = r + 1;
	}
	for( register char j = 1 ; j < 21 ; j++ )
		for( register int i = 1 ; i <= n ; i++ )
			f[j][i] = f[j - 1][ n < f[j - 1][i] ? n : f[j - 1][i] ];
	while( m-- )
	{
		int l = read() , r = read() , ans = 1;
		if( pre[r] - pre[l - 1] ) print( -1 );
		else
		{
			for( register char i = 20 ; ~i ; i-- )
				if( f[i][l] <= r )
					ans += 1 << i , l = f[i][l];
			print( ans );
		}
	}
	return 0;
}
