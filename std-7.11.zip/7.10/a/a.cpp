#include <iostream>
#include <stdio.h>
#define MAXN 500010

using namespace std;

int n , a[ MAXN ] , b[ MAXN ];
long long k , ans1 , ans2 , x;

inline bool win( int a , int b )
{
	if( a == 0 && b == 1 ) return 1;
	if( a == 1 && b == 2 ) return 1;
	if( a == 2 && b == 0 ) return 1;
	return 0;
}

inline long long f( long long a ) //����һ�� 
{
	if( a >= x ) return a - x + 1;
	return 0;
}

inline long long add( long long a , long long b ) //�ϲ����� 
{
	return f( a + b ) - f( a ) - f( b );
}

inline void cal( long long & ans , int a[] , int b[] )
{
	long long A = k / n , B = k % n;
	long long con1 = 0 , con2 = 0 , con3 = 0 , ans1 = 0 , ans2 = 0;
	for( int i = 1 ; i <= n && win( a[i] , b[i] ) ; i++ ) //A����ǰ׺��ʤ 
		con1++;
	for( int i = n ; i >= 1 && win( a[i] , b[i] ) ; i-- ) //A������׺��ʤ 
		con2++;
	if( con1 == n ) //�ᴩ
	{
		ans = k + f( k );
		return;
	}
	for( register int i = 1 ; i <= n ; i++ )
	{
		win( a[i] , b[i] ) ? con3++ : con3 = 0; 
		if( con3 >= x ) ans2++;
		ans1 += win( a[i] , b[i] );
		if( i == B )
		{
			ans += ans1;
			ans += ans2;
		}
	}
	con3 = 0;
	for( int i = 1 ; i <= B && win( a[i] , b[i] ) ; i++ ) //A����ǰ׺��ʤ 
		con3++;
	ans += ( ans1 + ans2 ) * A;
	if( A >= 1 ) ans += add( con2 , con3 ); //��1������׺�벻��ǰ׺�ϲ� 
	if( A >= 2 ) ans += ( A - 1 ) * add( con1 , con2 ); //��A-1������ǰ��׺�ϲ� 
}

int main()
{
	freopen( "a.in" , "r" , stdin );
	freopen( "a.out" , "w" , stdout );
	cin >> n >> k >> x;
	for( register int i = 1 ; i <= n ; i++ ) cin >> a[i];
	for( register int i = 1 ; i <= n ; i++ ) cin >> b[i];
	cal( ans1 , a , b );
	cal( ans2 , b , a );
	cout << ans1 << " " << ans2 << endl; 
	return 0;
}
