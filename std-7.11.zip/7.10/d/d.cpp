#include <iostream>
#include <stdio.h>
#include <vector>
#define MAXN 1000010
#define lowbit( i ) i & -i

using namespace std;

int n , m , ans[ MAXN ] , bit[ MAXN ];
vector < int > linker1[ MAXN ];
vector < pair < int , int > > linker2[ MAXN ];

struct io
{
	char ibuf[1 << 25] , * s , obuf[1 << 24] , * t;
	int a[24];
	io() : t( obuf )
	{
		freopen( "d.in" , "rb" , stdin );
		freopen( "d.out" , "w" , stdout );
		fread( s = ibuf , 1 , 1 << 25 , stdin );
	}
	~io()
	{
		fwrite( obuf , 1 , t - obuf , stdout );
	}
	inline int read()
	{
		register int u = 0;
		while( * s < 48 ) s++;
		while( * s > 32 )
			u = u * 10 + * s++ - 48;
		return u;
	}
	inline void pt( int u )
	{
		static int * q = a;
		if( !u ) * t++ = 48;
		else
		{
			while( u ) * q++ = u % 10 + 48 , u /= 10;
			while( q != a )
				* t++ = * --q;
		}
	}
	inline void print( int a )
	{
		if( a >= 0 )
			pt( a );
		else
			* t++ = 'C' , * t++ = 'h' , * t++ = 't' , * t++ = 'h' , * t++ = 'o' , * t++ = 'l' , * t++ = 'l' , * t++ = 'y';
		* t++ = '\n';
	}
} ip;

#define read ip.read
#define print ip.print

inline void modify( int x )
{
	for( int i = x ; i <= n ; i += lowbit( i ) )
		bit[i]++;
}

inline int find( int x )
{
	int ans = 0;
	for( int i = x ; i ; i -= lowbit( i ) )
		ans += bit[i];
	return ans;
}

int main()
{
	n = read() , m = read();
	for( int i = 1 ; i < n ; i++ )
	{
		int x = read() , y = read();
		if( x > y ) swap( x , y );
		x = min( x , i );
		y = max( y , i );
		linker1[x].push_back( y );
	}
	for( int i = 1 ; i <= m ; i++ )
	{
		int l = read() , r = read();
		linker2[l - 1].push_back( pair < int , int > ( r , -i ) );
		linker2[l - 1].push_back( pair < int , int > ( l - 1 , i ) );
		linker2[r].push_back( pair < int , int > ( r , i ) );
		linker2[r].push_back( pair < int , int > ( l - 1 , -i ) );
		ans[i] = -( r - l + 1 );
	}
	for( int i = 1 ; i <= n ; i++ )
	{
		for( int j = 0 ; j < linker1[i].size() ; j++ )
			modify( linker1[i][j] );
		for( int j = 0 ; j < linker2[i].size() ; j++ )
			if( linker2[i][j].second > 0 )
				ans[ linker2[i][j].second ] += find( linker2[i][j].first );
			else
				ans[ -linker2[i][j].second ] -= find( linker2[i][j].first );
	}
	for( int i = 1 ; i <= m ; i++ )
		print( -ans[i] );
	return 0;
}
