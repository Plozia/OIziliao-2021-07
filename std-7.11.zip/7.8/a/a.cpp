#include <iostream>
#include <stdio.h>
#include <math.h>
#define MAXN 10
#define pi 3.1415926535897932384626433832f

using namespace std;

string s , T1 , T2;
double a , b , c , d;

inline bool check( double k )
{
	if( s == "HEAT" )
	{
		if( b > 85 ) return 0;
		double f = d / cos( b * pi / 180 );
		return f < k;
	}
	else if( s == "HE" || s == "HESH" )
	{
		double f = d / cos( b * pi / 180 );
		return f < k;
	}
	else if( s == "AP" || s == "APCR" || s == "APFSDS" )
	{
		double f = d , ang = s == "AP" ? 5 : 2 , B = b;
		if( c > d * 3 ) ang *= 3;
		else if( c > d * 2 ) ang *= 2;
		B = max( B - ang , 0.0 );
		if( B > 70 ) return 0;
		f /= cos( B * pi / 180 );
		return f < k;
	}
}

int main()
{
	freopen( "a.in" , "r" , stdin );
	freopen( "a.out" , "w" , stdout );
	cin >> T1 >> T2;
	cin >> s >> a >> b >> c >> d;
	if( check( a * 0.75 ) ) cout << "Penetration!" << endl;
	else if( !check( a * 1.25 ) ) cout << "We didn't penetrate their armor!" << endl;
	else cout << "Server is important~" << endl;
	return 0;
}

