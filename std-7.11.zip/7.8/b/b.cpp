#include <iostream>
#include <stdio.h>
#include <set>
#include <map>

using namespace std;

int n , m , ans = 2147483647;
map < int , set < int > > pos;

inline int read()
{
	register int x = 0 , ch = getchar();
	while( !isdigit( ch ) ) ch = getchar();
	while( isdigit( ch ) ) x = x * 10 + ch - '0' , ch = getchar();
	return x;
}

inline void insert( int v , int x )
{
	set < int > :: iterator it = pos[v].lower_bound( x );
	if( it != pos[v].end() ) ans = min( ans , * it - x );
	if( it != pos[v].begin() ) ans = min( ans , x - * --it );
	pos[v].insert( x );
}

int main()
{
	freopen( "b.in" , "r" , stdin );
	freopen( "b.out" , "w" , stdout );
	n = read() , m = read();
	for( register int i = 1 ; i <= n ; i++ )
		insert( read() , i );
	while( m-- )
	{
		int x = read() , y = read();
		if( x != y )
		{
			if( pos[x].size() > pos[y].size() ) swap( pos[x] , pos[y] );
			for( register set < int > :: iterator i = pos[x].begin() ; i != pos[x].end() ; ++i )
				insert( y , * i );
			pos[x].clear();
		}
		printf( "%d\n" , ans );
	}
	return 0;
}
