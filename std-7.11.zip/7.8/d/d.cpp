#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
#define fi first
#define se second
const int N=210000;
const long long INF=1e18;
int A[N];
struct atom{
	long long seg,pre;
};
int n;
vector<atom> L,R;
struct atom2{
	long long x,y;
	int pd;
	long long value;
};
vector<atom2> B;
unsigned long long ans;
long long y[N<<1];
int now;
long long C[N<<1],D[N<<1];
int compare(const atom2& k1,const atom2& k2){
	return k1.x<k2.x||(k1.x==k2.x&&k1.pd<k2.pd);
}
void preprocess(){
	sort(B.begin(),B.end(),compare);
	now=0;
	for (int i=0;i<B.size();++i) y[++now]=B[i].y;
	sort(y+1,y+now+1);
	now=unique(y+1,y+now+1)-y-1;
	for (int i=0;i<B.size();++i) B[i].y=lower_bound(y+1,y+now+1,B[i].y)-y;
}
void add(long long* C,int pos,long long value){
	for (;pos<=now;pos+=pos&(-pos)) C[pos]+=value;
}
long long find(long long* C,int pos){
	long long ans=0;
	for (;pos;pos-=pos&(-pos)) ans+=C[pos];
	return ans;
}
void deal(){
	preprocess();
	for (int i=1;i<=now;i++) C[i]=0;
	for (int i=0;i<B.size();++i){
		if (B[i].pd==0) add(C,B[i].y,1); else
			ans+=B[i].value*find(C,B[i].y); 
	}
}
void deal2(){
	preprocess();
	for (int i=1;i<=now;i++) C[i]=D[i]=0;
	for (int i=0;i<B.size();++i){
		if (B[i].pd==0){
			add(C,B[i].y,1); add(D,B[i].y,B[i].value);
		} else ans+=B[i].value*find(C,B[i].y)+find(D,B[i].y);
	}
}
void solve(int l,int r){
	if (l==r){
		ans+=A[l]; return;
	}
	int mid=l+r>>1;
	solve(l,mid); solve(mid+1,r);
	L.clear(); R.clear();
	long long max_pre=-INF,max_seg=-INF,max_suf=-INF,sum=0;
	for (int i=mid;i>=l;i--){
		sum+=A[i];
		max_pre=max(max_pre,sum);
		max_suf=max(max_suf,0ll)+A[i];
		max_seg=max(max_seg, max_suf);
		L.push_back((atom){max_seg, max_pre});
	}
	max_pre=max_seg=max_suf=-INF; sum=0;
	for (int i=mid+1;i<=r;i++){
		sum+=A[i];
		max_pre=max(max_pre,sum);
		max_suf=max(max_suf,0ll)+A[i];
		max_seg=max(max_seg,max_suf);
		R.push_back((atom){max_seg, max_pre});
	}
	// cout<<"dealwith "<<l<<" "<<r<<" "<<ans<<endl;
	// Case1: L.seg
	// Condition: L.seg >= R.seg && L.seg - L.pre >= R.pre
	B.clear();
	for (int i=0;i<L.size();++i) B.push_back((atom2){L[i].seg,L[i].seg-L[i].pre,1,L[i].seg});
	for (int i=0;i<R.size();++i) B.push_back((atom2){R[i].seg,R[i].pre,0,0});
	deal();
	// cout<<"finish case1 "<<ans<<endl;
	
	// Case2: R.seg
	// Condition: R.seg >= L.seg + 1 && R.seg - R.pre >= L.pre
	B.clear();
	for (int i=0;i<R.size();++i) B.push_back((atom2){R[i].seg,R[i].seg-R[i].pre,1,R[i].seg});
	for (int i=0;i<L.size();++i) B.push_back((atom2){L[i].seg+1,L[i].pre,0,0});
	deal();
	// cout<<"finish case2 "<<ans<<endl;
	
	// Case2: L.pre + R.pre
	// Condition: L.pre - L.seg >= -R.pre + 1 && L.pre >= R.seg - R.pre + 1
	B.clear();
	for (int i=0;i<L.size();++i) B.push_back((atom2){L[i].pre-L[i].seg,L[i].pre,1,L[i].pre});
	for (int i=0;i<R.size();++i) B.push_back((atom2){-R[i].pre+1,R[i].seg-R[i].pre+1,0,R[i].pre});
	deal2();
	// cout<<"finish case3 "<<ans<<endl;
} 
int main(){
	freopen( "d.in" , "r" , stdin );
	freopen( "d.out" , "w" , stdout );
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d",&A[i]);
	solve(1,n);
	cout<<ans<<endl; 
}
