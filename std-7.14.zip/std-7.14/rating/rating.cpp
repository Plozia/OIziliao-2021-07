#include <bits/stdc++.h>

using namespace std;

int n, m, a[5001], f[5001];

int main() {
	freopen("rating.in", "r", stdin);
	freopen("rating.out", "w", stdout); 
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++)
        scanf("%d", &a[i]);
    memset(f, 127, sizeof(f));
    f[1] = 1;
    int ans = 1e9;
    for (int i = 1; i <= n; i++) {
        bool ok = true;
        for (int j = i + 1; j <= n && ok; j++) {
            f[j] = min(f[j], f[i] + 1);
            if (abs(a[j] - a[i]) > m)
                ok = false;
        }
        if (ok)
            ans = min(ans, f[i]);
    }
    printf("%d\n", ans);
}

