#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int n, c[1000001], f[1000001], v[1000001], w[1000001], p[1000001];
vector<int> a[1000001];

int gf(int i) {
    if (f[i] == i)
        return i;
    return f[i] = gf(f[i]);
}

long long calc(vector<int> c) {
    int m = c.size();
    long long ans = 0;
    for (int i = 0; i < 1 << m; i++) {
        long long res = 0;
        for (int j = 0; j < m; j++)
            if (i & (1 << j))
                p[c[j]] = 1, res += v[c[j]];
            else
                p[c[j]] = 0;
        for (int j = 0; j < m; j++)
            if (p[c[j]] && c[j] != 1) {
                for (long long k = 1LL * c[j] * c[j]; k <= n; k *= c[j]) {
                    if (p[k])
                        res -= w[k];
                }
            }
        ans = max(ans, res);
    }
    return ans;
}

int main() {
	freopen("set.in", "r", stdin);
	freopen("set.out", "w", stdout); 
    scanf("%d", &n);
    
    for (int i = 1; i <= n; i++)
        scanf("%d", &v[i]);
    
    for (int i = 1; i <= n; i++)
        scanf("%d", &w[i]);
    
    
    for (int i = 1; i <= n; i++)
        f[i] = i;
    
    for (int i = 2; i <= n; i++)
        for (long long j = 1LL * i * i; j <= n; j *= i)
            ++c[j], f[gf(j)] = gf(i);
    
    for (int i = 1; i <= n; i++)
        a[i].clear();

    for (int i = 1; i <= n; i++)
        a[gf(i)].push_back(i);
    
    long long ans = 0;
    
    memset(p, 0, sizeof(p));
    for (int i = 1; i <= n; i++)
        ans += calc(a[i]);
    
    printf("%lld\n", ans);    
}

