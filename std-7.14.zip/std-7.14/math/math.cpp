#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

ll n;

int main() {
	
	freopen("math.in", "r", stdin);
	freopen("math.out", "w", stdout); 
    cin >> n;
    long long m = n + 1;
    if(n <= 3) {
        if(n == 2) {
            cout << 1 << endl;
        }
        if(n == 3) {
            cout << 2 << endl;
        }
        return 0;
    }
    if(n & 1) {
        m /= 2;
    }
    else {
        n /= 2;
    }
    
    ll mn = min(m, n);
    mn = sqrt(mn + 1);
    
    for(int i = 2; i <= mn; ++i) {
        if(m % i == 0 || n % i == 0) {
            if(m % i == 0) {
                cout << m / i * n << endl;
            }
            else {
                cout << n / i * m << endl;
            }
            return 0;
        }
    }

    cout << max(n, m) << endl;
    return 0;
}
