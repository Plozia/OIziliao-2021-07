#include<vector>
#include<set>
#include<map>
#include<queue>
#include<string>
#include<algorithm>
#include<iostream>
#include<bitset>
#include<functional>
#include<numeric>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cassert>
#include<cmath>
#include<iomanip>
#include<random>
#include<ctime>
#include<complex>
using namespace std;
typedef long long LL;
typedef double D;
#define all(v) (v).begin(), (v).end()
mt19937 gene(233);
typedef complex<double> Complex;
#define fi first
#define se second
#define ins insert
#define pb push_back
inline char GET_CHAR(){
    const int maxn = 131072;
    static char buf[maxn],*p1=buf,*p2=buf;
    return p1==p2&&(p2=(p1=buf)+fread(buf,1,maxn,stdin),p1==p2)?EOF:*p1++;
}
inline int getInt() {
    int res(0);
    char c = getchar();
    while(c < '0') c = getchar();
    while(c >= '0') {
        res = res * 10 + (c - '0');
        c = getchar();
    }
    return res;
}

inline LL fastpo(LL x, LL n, LL mod) {
    LL res(1);
    while(n) {
        if(n & 1) {
            res = res * (LL)x % mod;
        }
        x = x * (LL) x % mod;
        n /= 2;
    }
    return res;
}
LL gcd(LL a, LL b) { return b ? gcd(b, a % b) : a; }

inline string itoa(int x, int width = 0) {
    string res;
    if(x == 0) res.push_back('0');
    while(x) {
        res.push_back('0' + x % 10);
        x /= 10;
    }
    while((int)res.size() < width) res.push_back('0');
    reverse(res.begin(), res.end());
    return res;
}
const int _B = 131072;
char buf[_B];
int _bl = 0;
inline void flush() {
    fwrite(buf, 1, _bl, stdout);
    _bl = 0;
}
__inline void _putchar(char c) {
    if(_bl == _B) flush();
    buf[_bl++] = c;
}
inline void print(LL x, char c) {
    static char tmp[20];
    int l = 0;
    if(!x) tmp[l++] = '0';
    else {
        while(x) {
            tmp[l++] = x % 10 + '0';
            x /= 10;
        }
    }
    for(int i = l - 1; i >= 0; i--) _putchar(tmp[i]);
    _putchar(c);
}
struct P {
    D x, y;
};
const int N = 5055;
const int LOG = 20;
const int mod = 1e9 + 7;
const int inf = 1e9 + 7;
int n, m;
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};
vector<int> e[N];
int dis[N][N], mn[N];
void update(LL k, LL a, LL b) {
    if(b < inf / 2 && a < inf / 2)
        mn[b] = min(mn[b], (int)a);
}
LL solve(LL lim) {
    //return max j such that j * (j + 1) < lim
    LL res = sqrt(1 + 4 * lim) / 2;
    while(res > 0 && res * (res + 1) >= lim) res--;
    return res;
}
D calc(LL k, LL a, LL b) {
    if(a > inf / 2) return inf;
    if(a == 0) {
        if(b == 0) return 0;
        LL v = k / b + 1;
        LL count_v_plus_1 = k % b;
        return (b - count_v_plus_1) * 2. / (v) + count_v_plus_1 * 2. / (v + 1);
    }
    if(b == 0) {
        LL v = k / a + 1;
        LL count_v_plus_1 = k % a;
        return (a - count_v_plus_1) * 1. / (v) + count_v_plus_1 * 1. / (v + 1);
    }
    
    LL le = 0, ri = k;
    while(le != ri) {
        LL inc_a = (le + ri + 1) / 2;
        //cout << le << ' ' << ri << ' ' << inc_a << endl;
        LL cost_a = inc_a * a;
        LL inc_b = solve(2 * inc_a * (inc_a + 1));
        LL cost_b = inc_b * b;
        if(cost_a + cost_b > k) {
            ri = inc_a - 1;
        }else {
            le = inc_a;
        }
    }
    LL inc_a = le;
    LL inc_b = solve(2 * inc_a * (inc_a + 1));
    //printf("inca = %d, incb = %d\n", (int)inc_a, (int)inc_b);
    k -= inc_a * a + inc_b * b;
    D resa = a * 1. / (1 + inc_a);
    D resb = b * 2. / (1 + inc_b);
    while(k) {
        //1 / (1+ia) / (2+ia) > 2 / (1+ib) / (2+ib)
        //cout << k << endl;
        if((1 + inc_b) * (2 + inc_b) > 2 * (1 + inc_a) * (2 + inc_a)) {
            LL mn = min(k, a);
            resa = mn * 1. / (2 + inc_a) + (a - mn) * 1. / (1 + inc_a);
            k -= mn;
            inc_a++;
        }else {
            LL mn = min(k, b);
            resb = mn * 2. / (2 + inc_b) + (b - mn) * 2. / (1 + inc_b);
            k -= mn;
            inc_b++;
        }
    }
    //cout << resa << ' ' << resb << endl;
    return resa + resb;
}
int main() {
	freopen("city.in", "r", stdin);
	freopen("city.out", "w", stdout); 
    int n, m, k;
    scanf("%d%d%d", &n, &m, &k);
    for(int i = 1; i <= m; i++) {
        int x, y;
        scanf("%d%d", &x, &y);
        e[x].pb(y);
        e[y].pb(x);
    }
    int s1, t1, s2, t2;
    scanf("%d%d%d%d", &s1, &t1, &s2, &t2);
    for(int i = 1; i <= n; i++) {
        fill(dis[i] + 1, dis[i] + 1 + n, inf);
        vector<int> q;
        q.pb(i);
        dis[i][i] = 0;
        for(int op = 0; op < (int)q.size(); op++) {
            int v = q[op];
            for(int y : e[v]) {
                if(dis[i][y] == inf) {
                    dis[i][y] = dis[i][v] + 1;
                    q.pb(y);
                }
            }
        }
    }
    fill(mn, mn + 1 + n, inf);
    update(k, dis[s1][t1] + dis[s2][t2], 0);
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            update(k, (LL)dis[i][s1] + dis[i][s2] + dis[j][t1] + dis[j][t2], dis[i][j]);
            update(k, (LL)dis[i][s1] + dis[i][t2] + dis[j][t1] + dis[j][s2], dis[i][j]);
        }
    }
    D ans = inf;
    for(int i = 0; i <= n; i++) {
        int a = mn[i], b = i;
        //printf("ab %d %d\n", a, b);
        ans = min(ans, calc(k, a, b));
    }
    printf("%.12f\n", ans);
}




